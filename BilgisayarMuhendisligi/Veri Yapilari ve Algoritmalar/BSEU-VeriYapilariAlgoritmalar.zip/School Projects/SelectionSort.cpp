// Selection Sort (Secmeli Siralama)
#include <iostream>
using namespace std;

void SelectionSort(int arr[], int arrLength) {
	for(int i=0; i<arrLength-1;i++ ) {
		int min = i;
		for(int j=i+1; j<arrLength; j++){
			if(arr[min] > arr[j]) {
				min = j;
			}
		}
		// swap(arr[i],arr[min])
		int temp = arr[i];
		arr[i] = arr[min];
		arr[min] = temp;
	}
}

void Display(int arr[],int arrLength) {
	for(int i=0;i<arrLength;i++) {
		cout << arr[i] << " ";
	}
	cout << endl;
}

int main() {
	int dizi[10] = {10,2,0,14,43,25,18,-1,5,-45};
	int uzunluk = sizeof(dizi)/sizeof(dizi[0]);
	cout << "Siralanmamis dizi: "; Display(dizi,uzunluk);
	cout << "Selection Sort ile siralanmis dizi: "; SelectionSort(dizi,uzunluk); Display(dizi,uzunluk);	
	
	return 0;
}

