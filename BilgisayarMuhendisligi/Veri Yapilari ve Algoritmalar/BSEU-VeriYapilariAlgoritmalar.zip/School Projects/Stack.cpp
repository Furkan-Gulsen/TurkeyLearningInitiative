#include <iostream> 
using namespace std; 
// Stack 
const int STACK_MAX = 10; 
class Stack { 
	public: 
		Stack();			// Yigini hazirlar. Top degiskenine 0 atar. 
		bool Push(int item); // item degerini yigina ekler. 
		int Pop();			// Yigina son eklenen elemani cikararak, cikarilan elemani dondurur. 
		bool isEmpty();  	// Yiginn bos mu dolu mu kontrol eder. Bos ise true , dolu ise false dondurur. 
		int TopReturn();  	// Yigindan eleman cikarmadan son eklenen eleman degerini dondurur. 
		void WriteAll();	// Yigindaki tum elemanlari yazdirir.  
		void DeleteAll();	// Yigindaki tum elemanlari Top degerini 0 yaparak silmis olur. 
		void WriteTop(); 
		int GetTop(); 
	private:	 
		int D[STACK_MAX];	// Yiginin tutuldugu yer. (Yigin dizisi) 
		int Top;			// Yigindaki son elemanin bir ust indisini tutar. 
}; 
Stack::Stack() { 
	Top = 0; 
} 
bool Stack::isEmpty() { 
	if(Top <=0) { 
		return true; 
	} 
	// else 
	return false; 
} 
bool Stack::Push(int item) { 
	if(Top >= STACK_MAX){ // Yigindaki Top degeri dizinin boyutundan buyuk ve esitse, yigina eleman eklenemedigi icin false dondurur. 
		return false; 
	} 
	D[Top] = item; 
	Top++; 
	return true; 
} 
int Stack::Pop() { 
	if(Top <= 0){ 
		return -1; 
	} 
	Top--; 
	int item = D[Top]; 
	return item; 
} 
int Stack::TopReturn(){ 	// Yiginin en ustundeki elemani yazdiran fonksiyon
	if(Top <= 0){ 
		return -1;	 
	} 
	int item = D[Top-1]; 
	return item; 
} 
void Stack::DeleteAll(){ 
	Top = 0; 
} 
void Stack::WriteAll() { 
	while(TopReturn() != -1) { 
		cout << Pop() << " "; 
	} 
} 
/* 
void Stack::WriteTop(){ 
} 
int Stack::GetTop(){ 
} 
*/ 
int main() { 
	Stack object; 
	object.Push(1); 
	object.Push(3);
	object.Push(10);
	object.Push(-4);
	object.Push(9);
	object.Pop();
	object.Pop();
	object.WriteAll(); 
	
	return 0; 
}
