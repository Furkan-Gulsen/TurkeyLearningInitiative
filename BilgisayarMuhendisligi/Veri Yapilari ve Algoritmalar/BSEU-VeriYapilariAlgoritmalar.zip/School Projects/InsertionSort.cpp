// Insertion Sort (Eklemeli Siralama)
#include <iostream>
using namespace std;

void InsertionSort(int arr[], int arrLength) {
	int key,j,i;
	
	for(i=1;i<arrLength;i++) {
		key = arr[i];			// Select the first unsorted element
		for(j = i-1; (j>=0) && (arr[j] > key); j--) {
			arr[j+1] = arr[j];
		}
		arr[j+1] = key;
	}
}

void Display(int arr[],int arrLength) {
	for(int i=0;i<arrLength;i++) {
		cout << arr[i] << " ";
	}
	cout << endl;
}


int main() {
	int dizi[10] = {10,2,0,14,43,25,18,-1,5,-45};
	int uzunluk = sizeof(dizi)/sizeof(dizi[0]);
	cout << "Siralanmamis dizi: "; Display(dizi,uzunluk);
	cout << "Insertion Sort ile siralanmis dizi: "; InsertionSort(dizi,uzunluk); Display(dizi,uzunluk);
	
	return 0;
}

