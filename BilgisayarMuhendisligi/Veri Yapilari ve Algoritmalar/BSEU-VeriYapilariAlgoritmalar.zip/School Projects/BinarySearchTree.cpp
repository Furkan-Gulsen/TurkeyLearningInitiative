#include <iostream>
using namespace std;
// Binary Search Tree
class BSTDugum {
	public:
		int Veri;
		BSTDugum* pSol;
		BSTDugum* pSag;
		
		BSTDugum(int Veri) {	// Constructor
			this->Veri = Veri;
			pSol = NULL;
			pSag = NULL;
		}
		//Fonksiyonlar
		void Ekle(int item); 
		BSTDugum* Ara(int item);
		void Cikar(int item,BSTDugum* ebeveyn = NULL);
		int MinGetir();  //Sagdan Min Getir
		void printPreOrder(BSTDugum* gecici);	
		void printInOrder(BSTDugum* gecici);
		void printPostOrder(BSTDugum* gecici);
};

void BSTDugum::Ekle(int item) {
	if(Veri > item) {
		if(pSol != NULL) {              // if(pSol)  == if(pSol != NULL)
			return pSol->Ekle(item);	// Sol dugumde eleman oldugu durumlarda calisir.
		}
		BSTDugum* pYeni = new BSTDugum(item);
		pSol = pYeni;
	}
	else if (Veri < item) {
		if(pSag != NULL) {				// Sag dugumde dugum var mi diye kontrol eder.
			return pSag -> Ekle(item);	// Sag dugumde eleman oldugu durumlarda calisir.
		}
		BSTDugum* pYeni = new BSTDugum(item);
		pSag = pYeni;
	}
}

BSTDugum* BSTDugum::Ara(int item) {
	if(Veri > item) {
		if(pSol != NULL)			    // Sol dugumde dugum var mi diye kontrol eder.
			return pSol -> Ara(item);   // Sol dugumde eleman oldugu durumlarda calisir.
		else
			return NULL;
	}
	else if(Veri < item) {
		if(pSag != NULL)
			return pSag -> Ara(item);
		else
			return NULL;	
	}
	return this;  // Dugumu geri dondurur.
}

int BSTDugum::MinGetir() {
	if(pSol != NULL)
		return pSol->MinGetir();
	return Veri; // return this->Veri;	
}

void BSTDugum::Cikar(int item,BSTDugum* ebeveyn) {
	if(Veri > item) {
		if(pSol != NULL)
			return pSol->Cikar(item,this);
		else
			return;	
	}
	if(Veri < item) {
		if(pSag != NULL)
			return pSag -> Cikar(item,this);
		else
			return;	
	}
	//if(Veri == item) 		// Silinecek dugum icin
	if(pSol == NULL && pSag == NULL) { // Saginda ve solunda dugum yoksa
		if(ebeveyn -> pSol == this)
			ebeveyn -> pSol = NULL;
		else
			ebeveyn -> pSag = NULL;	
	}
	else if(pSag != NULL && pSol != NULL) {	// Saginda ve solunda dugum varsa
		Veri = pSag->MinGetir();											// int SagMin = pSag->MinGetir();
		return pSag->Cikar(Veri,this);										// this->Veri = SagMin;
																			// return pSag->Cikar(SagMin,this);
	}
	else if (pSag != NULL) {  // Sadece Saginda dugum varsa
		if(ebeveyn -> pSol == this) 
			ebeveyn -> pSol = this -> pSag;		// this: silinecek eleman
		else
			ebeveyn -> pSag = this -> pSag;	    // ebeveyn -> pSag = pSag;
	}
	else {   // Sadece solunda dugum varsa
		if(ebeveyn -> pSol == this)
			ebeveyn -> pSol == this -> pSol; // ebeveyn->pSol = pSol;
		else
			ebeveyn->pSag = this->pSol;	
	}
	delete this;
}

void printPreOrder(BSTDugum* gecici) { // gecici = root degeri
	if(gecici != NULL) {
		cout << gecici->Veri << "  ";
		printPreOrder(gecici->pSol);
		printPreOrder(gecici->pSag);
	}
}

void printInOrder(BSTDugum* gecici) {   
	if(gecici != NULL) {
		printInOrder(gecici->pSol);
		cout << gecici->Veri << "  ";
		printInOrder(gecici->pSag);
	}
}

void printPostOrder(BSTDugum* gecici) {
	if(gecici != NULL) {
		printPostOrder(gecici->pSol);
		printPostOrder(gecici->pSag);
		cout << gecici->Veri << "  ";
	}
}


int main() {
	BSTDugum* A = new BSTDugum(10); // Root Veri = 10;
	A->Ekle(5);
	A->Ekle(15);
	A->Ekle(8);
	A->Ekle(7);
	A->Ekle(9);
	A->Ekle(12);
	A->Ekle(14);
	A->Ekle(3);
	A->Ekle(4);
	A->Ekle(2);
	A->Ekle(11);
	
	cout << "PreOrder = ";	printPreOrder(A);   cout<<endl;
	cout << "InOrder = ";	printInOrder(A);	cout<<endl;
	cout << "PostOrder = "; printPostOrder(A);  cout<<endl;
	
	return 0;
}
