// Binary Search(�kili Arama)
#include <iostream>
using namespace std;

// Arrayi kucukten buyuge siralama
void ArraySorting(int arr[],int arrLength) {
	int temp;
	for(int i=0;i<arrLength;i++){
		for(int j=1;j<arrLength;j++){	// Dizi
			if(arr[j-1] >arr[j]) {
				temp = arr[j-1];
				arr[j-1] = arr[j];
				arr[j] = temp;
			}			
		}
	}
}
void DisplayArray(int arr[],int arrLength){
	for(int i=0;i<arrLength;i++){
		cout << arr[i] << " ";
	}
}

int BinarySearch(int arr[], int arrLength, int aranan) {
	int temp;
	int alt = 0, ust = arrLength-1;
	while(alt <= ust) {
		int orta = (alt+ust) / 2;
		if(aranan == arr[orta]) {
			return orta;
		} else if(aranan < arr[orta]) {
			ust = orta - 1;
		} else {
			alt = orta + 1;
		}
	}
	return -1;
}


int main() {
	int aranan,N;
	cout << "Dizinin eleman sayisini giriniz: ";
	cin >> N;
	int arr[N];				// arrLength = sizeof(arr) / sizeof(arr[0])
	for(int i=0;i<N;i++) {
		cout << "Dizinin " << i <<". indisli elemanini giriniz: ";
		cin >> arr[i];
	}
	cout << "Olusturdugunuz dizi: ";
	for(int i=0;i<N;i++) {
		cout << arr[i] << " ";
	}
	ArraySorting(arr,N);
	cout << "\nDizinin kucukten buyuge siralanmis hali: ";
	DisplayArray(arr,N);
	cout << "\nDizide aradiginiz sayiyi giriniz: ";
	cin >> aranan;
	
	int result = BinarySearch(arr,N,aranan);
	if(result == -1) {
		cout << "Aradiginiz " << aranan << " elemani dizide yok."; 
	} else {
		cout << "Aradiginiz " << aranan << " elemani dizinin "<< result << ". indisinde."; 
	}

	return 0;
}

