#include <iostream>
using namespace std;
const int MAX = 10;
// Min Heap
class Heap {
	public:
		Heap();
		int SolCocukGetir(int i);
		int SagCocukGetir(int i);
		int EbeveynGetir(int i);
		bool Ekle(int item);
		bool Getir(/*int &item*/);
		void Yazdir();
		//bool HeapOlustur(int a[], int ES);  // ES: eleman sayisi
		void HeapifyUp(int i);
		void HeapifyDown(int i);
	private:
		int Veri[MAX];
		int ES;	
};

Heap::Heap() {
	ES = 0;
} 

int Heap::SolCocukGetir(int i) {
	return 2*i+1;
}

int Heap::SagCocukGetir(int i) {
	return 2*i+2;
}

int Heap::EbeveynGetir(int i) {
	return (i-1)/2;
}

bool Heap::Ekle(int item) {
	if(ES == MAX) {
		return false;
	}
	ES++;
	Veri[ES-1] = item;
	HeapifyUp(ES-1);
	return true;
}

void Heap::HeapifyUp(int i) {
	if(i == 0) {	// Kok dugum mu?
		return;
	}
	int eb = EbeveynGetir(i);
	
	if(Veri[eb] > Veri[i]) {
		int temp = Veri[i];
		Veri[i] = Veri[eb];
		Veri[eb] = temp;
		HeapifyUp(eb);
	}
}

bool Heap::Getir(/*int &item*/) { // Getir fonksiyonu getirilen dugumu Heapten cikarir.
	if(ES == 0) {
		return false;
	}
	//item = Veri[0];
	Veri[0] = Veri[ES-1];
	ES--;
	HeapifyDown(0);  // kok degeri parametre olarak alindi.
	return true;
}

void Heap::HeapifyDown(int i) {
	int Sol = SolCocukGetir(i);
	int Sag = SagCocukGetir(i);
	int min;  // Kucuk olan cocugun index degeri
	
	if(Sag >= ES) {
		if(Sol >= ES)
			return;
		else
			min = Sol;	
	}
	else {		// Dugumun iki cocugu varsa 
		if(Veri[Sol] < Veri[Sag])
			min = Sol;
		else
			min = Sag;	
	}
	if(Veri[min]<Veri[i]){
		int temp = Veri[i];
		Veri[i] = Veri[min];
		Veri[min] = temp;
		HeapifyDown(min);
	}
}

void Heap::Yazdir() {
	for(int i=0;i<ES;i++) {
		cout << Veri[i] << " ";
	}
	cout << endl;
}


int main() {
	Heap heap;
	heap.Ekle(5);
	heap.Ekle(3);
	heap.Ekle(7);
	heap.Ekle(8);
	heap.Ekle(4);
	heap.Ekle(6);
	heap.Ekle(1);
	heap.Yazdir();	
	heap.Getir();
	heap.Yazdir();
	
	return 0;
}
