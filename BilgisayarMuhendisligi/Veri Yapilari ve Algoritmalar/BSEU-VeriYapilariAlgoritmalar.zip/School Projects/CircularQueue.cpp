#include <iostream>
using namespace std;

const int KUYRUK_MAX = 10;

class CircularQueue{
	public:
		CircularQueue();  	 // Constructor - Kuyrugu baslangic durumuna getirir.
		bool Ekle(int item); // Kuyrugun sonuna eleman ekler.
		int Cikar();		 // Kuyrugun basindaki elemani cikarir.
		bool BosMu();		 // Kuyruk bos mu degil mi kontrol eder.
		void Yazdir();		 // Kuyrugun basindan sonuna kadar tum elemanlari ekrana yazar.
	private:
		int D[KUYRUK_MAX];	 	// Kuyruk elemanlarinin saklanacagi dizi
		int KS,KB,ES;			
		// KB: Kuyruk basi (Kuyrugun ilk elemaninin indisini tutar)
		// KS: Kuyruk sonu (Kuyrugun son elemaninin indisini tutar) 
		// ES: Eleman sayisi (Kuyruktaki toplam eleman sayisini tutar)
};

CircularQueue::CircularQueue() {
	KB = -1; 
	KS =-1;
	ES = 0;
}

bool CircularQueue::Ekle(int item) {
	if(ES >= KUYRUK_MAX) { // Kuyruk Dolu ise
		return false;
	}
	if(KB<=-1) {	// Kuyruk bos ise KB 1 arttirilir
		KB++;		
	}
	if(KS == KUYRUK_MAX-1) {  // Kuyruk sonu dizinin son elemani ise, KS=0 yap, degilse 1 arttir.
		KS = 0;
	} else {
		KS ++;
	}
	D[KS] = item;
	ES ++;
	return true;
}

int CircularQueue::Cikar() {
	if(ES == 0) {	// Kuyruk bos ise
		return -1;
	}
	int item = D[KB];
	if(KB == KUYRUK_MAX-1) { // KB dizinin son elemani ise KB=0 yap
		KB = 0;
	} else {
		KB++;
	}
	ES--;
	return item;
}

bool CircularQueue::BosMu() {
	if(ES == 0) {
		return true;
	}
	return false;
}

void CircularQueue::Yazdir() {
	if(ES == 0) {
		cout << "Kuyrukta eleman yoktur.";
	} if(KS >= KB) {
		for(int i=KB ; i <=KS;i++) {
			cout << D[i] << " ";
		}
		cout << endl;
	} else {
		for(int i=KB; i<= KUYRUK_MAX-1; i++) {
			cout << D[i] << " ";
		}
		for(int i=0; i<=KS; i++) {
			cout << D[i] << " ";
		}
		cout << endl;
	}
}

int main() {
	CircularQueue ref;
	 ref.Ekle(5);
	 ref.Ekle(7);
	 ref.Ekle(9);
	 ref.Ekle(11);
	 ref.Ekle(6);
	 ref.Yazdir();
	 ref.Cikar();
	 ref.Yazdir();
	 
	return 0;
}

