#include <iostream>
using namespace std;

int binarySearch(int dizi[],int aranan, int bas, int son) {
	while(bas <= son) {
		int orta = bas + (son - bas)/2;
		cout << "bas degeri: " << bas << " ";
		cout << "son degeri: " << son << " ";
		cout << "orta degeri: " << orta << endl;
		
		if(dizi[orta] == aranan) {
			return orta;
		}
		if (dizi[orta] < aranan) {
			bas = orta + 1;
		} else {
			son = orta - 1;
		}
	}
	return -1;
}

int main() {
	int dizi[] = {1,2,3,4,5,6,7,8,9};
	int sizeDizi = sizeof(dizi) / sizeof(dizi[0]);
	for(int i=0; i<sizeDizi;i++) {
		cout << dizi[i] << " ";
	} 
	cout<<endl;
	int result = binarySearch(dizi,7,1,9);
	if (result == -1) {
		cout << "Aranan eleman dizide bulunmuyor";
	} else {
		cout << "Aranan eleman dizinin " << result << ". indisinde";
	}

	return 0;
}
