#include <iostream> 
using namespace std; 
const int KUYRUK_MAX = 10; 
class CircularQueue{ 
	public: 
		CircularQueue();  	 // Constructor - Kuyrugu baslangic durumuna getirir. 
		bool Ekle(int item); // Kuyrugun sonuna eleman ekler. 
		int Cikar();		 // Kuyrugun basindaki elemani cikarir. 
		bool BosMu();		 // Kuyruk bos mu degil mi kontrol eder. 
		void Yazdir();		 // Kuyrugun basindan sonuna kadar tum elemanlari ekrana yazar. 
	private: 
		int D[KUYRUK_MAX];	 	// Kuyruk elemanlarinin saklanacagi dizi 
		int KS,KB,ES;			 
		// KB: Kuyruk basi (Kuyrugun ilk elemaninin indisini tutar) 
		// KS: Kuyruk sonu (Kuyrugun son elemaninin indisini tutar)  
		// ES: Eleman sayisi (Kuyruktaki toplam eleman sayisini tutar) 
}; 
CircularQueue::CircularQueue() { 
	KB = -1;  
	KS =-1; 
	ES = 0; 
} 
bool CircularQueue::Ekle(int item) { 
	if(ES >= KUYRUK_MAX) { // Kuyruk Dolu ise 
		return false; 
	} 
	if(KB<=-1) {	// Kuyruk bos ise KB 1 arttirilir 
		KB++;		 
	} 
	if(KS == KUYRUK_MAX-1) {  // Kuyruk sonu dizinin son elemani ise, KS=0 yap, degilse 1 arttir. 
		KS = 0; 
	} else { 
		KS ++; 
	} 
	D[KS] = item; 
	ES ++; 
	return true; 
} 
int CircularQueue::Cikar() { 
	if(ES == 0) {	// Kuyruk bos ise 
		return -1; 
	} 
	int item = D[KB]; 
	if(KB == KUYRUK_MAX-1) { // KB dizinin son elemani ise KB=0 yap 
		KB = 0; 
	} else { 
		KB++; 
	} 
	ES--; 
	return item; 
} 
bool CircularQueue::BosMu() { 
	if(ES == 0) { 
		return true; 
	} 
	return false; 
} 
void CircularQueue::Yazdir() { 
	if(ES == 0) { 
		cout << "Kuyrukta eleman yoktur."; 
	} if(KS >= KB) { 
		for(int i=KB ; i <=KS;i++) { 
			cout << D[i] << " "; 
		} 
		cout << endl; 
	} else { 
		for(int i=KB; i<= KUYRUK_MAX-1; i++) { 
			cout << D[i] << " "; 
		} 
		for(int i=0; i<=KS; i++) { 
			cout << D[i] << " "; 
		} 
		cout << endl; 
	} 
} 
int main() { 
	CircularQueue ref;
	int x;
	while(x!=4 || !(x<=4)){
		cout << "1-Eleman ekle\n";
		cout << "2-Eleman cikar\n";
		cout << "3-Elemanlari goruntule\n";
		cout << "4-Cikis\n";
		cout << "Yapmak istediginiz islemi giriniz:\n";
		cin >> x;
		
		switch(x) {
			case 1:{
				cout << "Eklemek istediginiz elemani girin:";
				int item;
				cin >> item;
				ref.Ekle(item);
				break;
			}
			case 2:{
				ref.Cikar();
				break;
			}
			case 3: {
				ref.Yazdir();
				break;
			}
			case 4: {
				
				break;
			}	
		}
	}
	return 0; 
}
