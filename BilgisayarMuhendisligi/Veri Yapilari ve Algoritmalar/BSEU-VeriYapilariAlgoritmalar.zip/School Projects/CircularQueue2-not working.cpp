#include <iostream>
using namespace std;

const int KUYRUK_MAX = 10;
class CircularQueue {
	public:
		CircularQueue();
		bool Ekle(int item);
		int Cikar();
		bool BosMu();
		void Yazdir();
	private:	
		int D[KUYRUK_MAX];
		int KS,KB,ES;
};

CircularQueue::CircularQueue(){
	KS,KB = -1;
	ES = 0;
};
bool CircularQueue::Ekle(int item) {
	if(ES >= KUYRUK_MAX) {
		return false;
	}
	if(KB <= -1) {
		KB++;
	}
	if(KS == KUYRUK_MAX-1) {
		KS == 0;
	} else {
		KS++;
	}
	D[KS] = item;
	ES++;
	
	return true;
}

int CircularQueue::Cikar() {
	if(ES == 0) {
		return -1;
	}
	int item = D[KB];
	if(KB == KUYRUK_MAX-1) {
		KB = 0;
	} else {
		KB++;
	}
	ES--;
	return item;
}

bool CircularQueue::BosMu(){
	if(ES == 0) {
		return true;
	}
	return false;
}

void CircularQueue::Yazdir() {
	if(ES == 0) {
		cout << "Kuyrukta eleman yoktur.";
	}
	if(KS >= KB) {
		for(int i=KB; i<=KS; i++) {
			cout << D[i] << " ";
		} 
		cout << endl;
	}
	else {
		for(int i=KB; i<=KUYRUK_MAX-1; i++) {
			cout << D[i] << " ";
		}
		for(int i=0; i<=KS; i++) {
			cout << D[i] << " ";
		} 
		cout << endl;
	}
}

int main() {
	
	CircularQueue ref;
	int x;
	while(x!=4 || !(x<=4)) {
		cout << "1-Eleman ekle\n";
		cout << "2-Eleman cikar\n";
		cout << "3-Elemanlari goruntule\n";
		cout << "4-Cikis\n\n";
		cout << "Yapmak istediginiz islemi giriniz:\n";
		cin >> x;
		
		switch(x) {
			case 1: {
				cout << "Eklemek istediginiz elemani giriniz: ";
				int item;
				cin >> item;
				ref.Ekle(item);
				break;
			}
			case 2:{
				ref.Cikar();
				break;
			}
			case 3: {
				ref.Yazdir();
				break;
			}
			case 4: {
				break;
			}		
		}
	}	
	return 0;
}

