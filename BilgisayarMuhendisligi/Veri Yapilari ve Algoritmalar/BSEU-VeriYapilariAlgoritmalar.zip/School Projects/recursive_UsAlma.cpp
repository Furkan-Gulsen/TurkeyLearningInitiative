#include <iostream>
using namespace std;

int UsAlma(int taban, int tavan) {
	if(taban == 0) {
		return 0;
	} else if(taban>0 && tavan == 0) {
		return 1;
	} else {
		return taban * UsAlma(taban,tavan-1);
	}
}

int main() {
	int sayi,us,sonuc;
	cout << "Sayiyi giriniz: ";
	cin >> sayi;
	cout << "Sayinin ussunu giriniz: ";
	cin >> us;
	sonuc = UsAlma(sayi,us);
	cout << sayi << " ^ " << us << " = " << sonuc;	
	
	return 0;
}

