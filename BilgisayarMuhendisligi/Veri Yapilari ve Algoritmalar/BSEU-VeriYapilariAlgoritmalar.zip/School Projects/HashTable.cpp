#include <iostream>
using namespace std;

class Dugum {
	public:
		int Anahtar;
		Dugum* pSonraki;
		
		Dugum(int Anahtar) {
			this->Anahtar = Anahtar;
			pSonraki = NULL;
		}
};

const int MAX = 10;,

class HashTable {
	public:
		Dugum* Veri[MAX];
		HashTable();
		void Ekle(int Anahtar);
		Dugum* Getir(int Anahtar);
		bool Cikar(int Anahtar);
};
HashTable::HashTable() {
	for(int i=0;i<MAX;i++){
		Veri[i] = NULL;
	}
}

void HashTable::Ekle(int Anahtar) {
	Dugum* pYeni = new Dugum(Anahtar);
	int mod = Anahtar % MAX;
	
	if(Veri[mod] == NULL) { // Indiste eleman yoksa
		Veri[mod] = pYeni;
		return;
	}
	Dugum* pTemp = Veri[mod];
	while(pTemp->pSonraki != NULL) {
		pTemp = pTemp->pSonraki;
	}
	pTemp->pSonraki = pYeni;
}

Dugum* HashTable::Getir(int Anahtar) {
	int mod = Anahtar % MAX;
	Dugum* pTemp = Veri[mod];
	
	while(pTemp != NULL) {
		if(pTemp->pSonraki == Anahtar)
			return pTemp;
		pTemp = pTemp->pSonraki;	
	}
	return NULL;
}

bool HashTable::Cikar(int Anahtar) {
	int mod = Anahtar % MAX;
	if(Veri[mod] == NULL)
		return;
	if(Veri[mod] -> pSonraki == NULL) {   // Veri[mod] dizisinde tek bir eleman varsa
		if(Veri[mod] -> Anahtar == Anahtar) {
			delete Veri[mod];
			Veri[mod] = NULL;
		}
		return;
	}
	if(Veri[mod] -> Anahtar == Anahtar) {
		Dugum* pDon = Veri[mod] -> pSonraki;
		delete Veri[mod];
		Veri[mod] = pDon;
		return;
	}
	Dugum* pTemp = Veri[mod];
	while(pTemp->pSonraki != NULL) {
		if(pTemp -> pSonraki -> Anahtar == Anahtar) {
			Dugum* pDon = pTemp -> pSonraki;
			pTemp->pSonraki = pDon->pSonraki;
			delete pDon;
			return;
		}
		pTemp = pTemp->pSonraki;
	}	
}


int main() {

	return 0;
}

