#include <iostream> 
using namespace std; 
class Dugum{ 
	public: 
		int Veri; 
		Dugum* pSonraki; 
		Dugum(){ // Constructor 
			pSonraki = NULL;		 
		} 
}; 
void SonaEkle(Dugum *pBas,Dugum *pY){ 
	Dugum *pTemp = pBas; 
	while(pTemp->pSonraki != NULL) { 
		pTemp = pTemp -> pSonraki; 
	} 
	pTemp -> pSonraki = pY; 
} 
Dugum* SondanCikar(Dugum *pBas) { 
	while(pBas->pSonraki->pSonraki != NULL) { 
		pBas = pBas -> pSonraki; 
	} 
	Dugum *pTemp = pBas->pSonraki; 
	pBas->pSonraki= NULL; 
	return pTemp; 
} 
void ListeyiYazdir(Dugum* pBas) {  
	while(pBas != NULL) {  
		cout << pBas -> Veri << " ";  
		pBas = pBas -> pSonraki;  
	}  
	cout << endl; 
}  
int main(){ 
	Dugum *p1 = new Dugum(); 
	Dugum *p2 = new Dugum(); 
	Dugum *p3 = new Dugum(); 
	Dugum *p4 = new Dugum(); 
	p1->Veri= 1;   
	p2->Veri= 4;  
	p3->Veri= 3;  
	p4->Veri= 5;  
	p1->pSonraki=p2;    	  
	p2->pSonraki=p4;  
	p4->pSonraki=p3;  
	Dugum *p5 = new Dugum(); 
	p5->Veri= 9; 
	SonaEkle(p1,p5); 
	ListeyiYazdir(p1); 
	/* 
	Dugum *pTemp = SondanCikar(p1); 
	cout << "Cikarilan eleman: " << pTemp ->Veri << endl; 
	cout << "Cikarilan eleman: " << SondanCikar(p1) << endl; 
	*/ 
	cout << "Cikarilan eleman: " <<SondanCikar(p1)->Veri <<endl; 
	cout << "Cikarilan eleman: " <<SondanCikar(p1)->Veri << endl; 
	cout << "Cikarilan eleman: " <<SondanCikar(p1)->Veri << endl; 
	ListeyiYazdir(p1); 
	return 0; 
}
