// Quick Sort (Hizli S�ralama)

#include <iostream>
#include <cstdlib>
using namespace std;

/*
// Swap two elements - Utility function  
void swap(int* a, int* b) 
{ 
    int t = *a; 
    *a = *b; 
    *b = t; 
} */

int Bol(int *sayilar,int alt,int ust) {
	int pivot = sayilar[(rand()%(ust-alt) + alt)];  // Pivot random seciliyor.
	while(alt < ust) {
		while(sayilar[alt] < pivot) {
			alt++;
		}
		while(sayilar[ust] > pivot) {
			ust--;
		}
		if(sayilar[alt] == sayilar[ust]) {
			alt++;
		} else if(alt < ust) { // Swap islemi
			int temp = sayilar[alt];
			sayilar[alt] = sayilar[ust];
			sayilar[ust] = temp;
		}
	}
	return ust;
}

void QuickSort(int *sayilar,int alt,int ust) {
	if(alt < ust) {
		int j = Bol(sayilar,alt,ust);  // pivot  // Partition the array
		// Sort the subarrays independently
		QuickSort(sayilar,alt,j-1);
		QuickSort(sayilar,j+1,ust);
	}
}

void displayArray(int arr[], int size) 
{ 
    int i; 
    for (i=0; i < size; i++) 
        cout<<arr[i]<<" ";     
}

int main() {
	int dizi[10] = {10,2,0,14,43,25,18,-1,5,-45};
	int arrSize = sizeof(dizi) / sizeof(dizi[0]);
	displayArray(dizi,arrSize);
	QuickSort(dizi,0,arrSize-1);
	cout <<"\nArray sorted with quick sort: ";
	displayArray(dizi,arrSize);
	
	return 0;
}

