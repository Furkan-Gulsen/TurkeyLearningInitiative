// Linear Search (Dogrusal Arama)
#include <iostream>
using namespace std;

int LinearSearch(int arr[],int arrLength,int aranan){
	for(int i=0;i<arrLength;i++){	
		if(arr[i] == aranan) {
			return i;
		}
	}
	return -1;
}

int main() {
	int aranan,N;
	cout << "Dizinin eleman sayisini giriniz: ";
	cin >> N;
	int arr[N];				// arrLength = sizeof(arr) / sizeof(arr[0])
	for(int i=0;i<N;i++) {
		cout << "Dizinin " << i <<". indisli elemanini giriniz: ";
		cin >> arr[i];
	}
	cout << "Olusturdugunuz dizi: ";
	for(int i=0;i<N;i++) {
		cout << arr[i] << " ";
	}
	cout << "\nDizide aradiginiz sayiyi giriniz: ";
	cin >> aranan;
	
	int result = LinearSearch(arr,N,aranan);
	if(result == -1) {
		cout << "Aradiginiz " << aranan << " elemani dizide yok."; 
	} else {
		cout << "Aradiginiz " << aranan << " elemani dizinin "<< result << ". indisinde."; 
	}
	
	return 0;
}

