#include <iostream>
using namespace std;

class Dugum {
	public:
		int Veri;
		Dugum* pSonraki;
		
		Dugum() {
			pSonraki = NULL;
		}
		
		void Listele(Dugum* pBas) {
			Dugum* pTemp = pBas;
			while(pTemp != NULL) {
				cout << pTemp->Veri << " ";
				pTemp = pTemp->pSonraki;
			}
			cout << endl;
		}
		
		void ArayaEkle(Dugum* pBas, Dugum* pYeni,int index) {
			for(int i=0; i<index-2;i++) {
				pBas = pBas->pSonraki;
			}
			pYeni->pSonraki= pBas->pSonraki;
			pBas->pSonraki = pYeni;
		}
		
		Dugum* AradanCikar(Dugum* pBas,int index) {
			for(int i=0;i<index-2;i++) {
				pBas = pBas->pSonraki;
			}
			Dugum* pTemp = pBas->pSonraki;
			pBas->pSonraki = pBas->pSonraki->pSonraki; 
			return pTemp;
		}
		
		void SonaEkle(Dugum* pBas,Dugum* pYeni) {
			Dugum* pTemp = pBas;
			while(pTemp->pSonraki != NULL) {
				//cout << pBas->Veri;
				pTemp=pTemp->pSonraki;
			}
			pTemp->pSonraki = pYeni;
		}
		
		Dugum* SondanCikar(Dugum* pBas){
			while(pBas->pSonraki->pSonraki != NULL) {
				pBas = pBas->pSonraki;
			}
			Dugum* pTemp = pBas->pSonraki;
			pBas->pSonraki= NULL; 
			return pTemp;
		}
		
		// Basa eleman ekleme
		void BasaEkle(Dugum* pBas,Dugum* pYeni) {
			pYeni->pSonraki = pBas;
		}
		
		// Bastan eleman cikarma
		Dugum* BastanCikar(Dugum* pBas) {
			Dugum* pTemp = pBas;
			pBas->pSonraki = NULL;
			return pTemp;
		}
		
};

int main() {
	Dugum* p1 = new Dugum(); 
	Dugum* p2 = new Dugum();
	Dugum* p3 = new Dugum();
	Dugum* p4 = new Dugum();
	Dugum* ref;
	
	p1->Veri = 1;
	p2->Veri = 4;
	p3->Veri = 3;
	p4->Veri = 5;
	
	p1->pSonraki = p2;
	p2->pSonraki = p3;
	p3->pSonraki = p4;
	
	
	ref->Listele(p1);
	ref->SondanCikar(p1);
	ref->Listele(p1);
	
	Dugum* p5 = new Dugum();
	p5->Veri=10;
	
	ref->SonaEkle(p1,p5);
	ref->Listele(p1);

	ref->AradanCikar(p1,2);
	ref->Listele(p1);
	
	Dugum* p6 = new Dugum();
	p6->Veri = 15;
	
	ref->ArayaEkle(p1,p6,3);
	ref->Listele(p1);
	
	ref->AradanCikar(p1,2);
	ref->Listele(p1);
	
	Dugum* p7 = new Dugum();
	p7->Veri = 40;
	
	ref->BasaEkle(p1,p7);
	ref->Listele(p7);
	
	ref->BastanCikar(p7);
	ref->Listele(p1);
	
	
	return 0;
}

