#include <iostream>
using namespace std;

class DoublyLinkedList{
	public:
		int Veri;
		DoublyLinkedList* pOnceki;
		DoublyLinkedList* pSonraki;
		
		DoublyLinkedList() {
			pOnceki= NULL;
			pSonraki= NULL;
		}
		
		void SonaEkle(DoublyLinkedList* pBas, DoublyLinkedList* pYeni) {
			DoublyLinkedList* pTemp = pBas;
			while(pTemp -> pSonraki != NULL) {
				pTemp = pTemp -> pSonraki;
			}
			pTemp -> pSonraki = pYeni;
			pYeni -> pOnceki = pTemp;
		}
		void ArayaEkle(DoublyLinkedList* pBas, DoublyLinkedList* pYeni,int index) {
			for(int i=0;i<index-2;i++) {
				pBas = pBas -> pSonraki;
			}
			pYeni->pSonraki = pBas->pSonraki;
			pBas->pSonraki->pOnceki = pYeni;
			pBas->pSonraki= pYeni;
			pYeni->pOnceki = pBas;
		}
		
		DoublyLinkedList* Cikar(DoublyLinkedList *pBas, int item) {
			while(pBas->Veri != NULL && pBas->pSonraki != NULL) {
				pBas = pBas -> pSonraki;
			}
			if(pBas->Veri != item) {
				cout << "Aranan deger bulunamadi.";
				return pBas;
			}
			// Sondan cikarma
			else if(pBas->pSonraki == NULL) {
				DoublyLinkedList* pTemp = pBas;
				pTemp->pOnceki->pSonraki = NULL;
				return pTemp;
			}
			// Bastan cikarma
			else if(pBas->pOnceki == NULL) {
				DoublyLinkedList* pTemp = pBas;
				pTemp->pSonraki->pOnceki = NULL;
				return pTemp;
			}
			else {
				pBas->pOnceki->pSonraki = pBas->pSonraki;
				pBas->pSonraki->pOnceki = pBas->pOnceki;
				return pBas;
			}
		}
		
		void Listele(DoublyLinkedList* pBas){
			while(pBas != NULL) {
				cout << pBas->Veri << " ";
				pBas = pBas->pSonraki;
			}
			cout<<endl;
		}
};

int main(){
	DoublyLinkedList* p1 = new DoublyLinkedList();
	DoublyLinkedList* p2 = new DoublyLinkedList();
	DoublyLinkedList* p3 = new DoublyLinkedList();
	DoublyLinkedList* p4 = new DoublyLinkedList();
	DoublyLinkedList* p5 = new DoublyLinkedList();
	
	DoublyLinkedList* ref;
	
	p1->Veri = 1;
	p2->Veri = 2;
	p3->Veri = 3;
	p4->Veri = 4;
	p5->Veri = 5;
	
	
	p1->pSonraki = p2;
	p2->pOnceki = p1;
	
	ref->SonaEkle(p1,p3);
	ref->Listele(p1);
	
	ref->SonaEkle(p1,p4);
	ref->Listele(p1);

	ref->SonaEkle(p1,p5);
	ref->Listele(p1);
	
	DoublyLinkedList* p6 = new DoublyLinkedList();
	p6->Veri = 6;
	
	ref->ArayaEkle(p1,p6,3);
	ref->Listele(p1);
	
	ref->Cikar(p1,5);
	ref->Listele(p1);
	
	
	return 0;
}
