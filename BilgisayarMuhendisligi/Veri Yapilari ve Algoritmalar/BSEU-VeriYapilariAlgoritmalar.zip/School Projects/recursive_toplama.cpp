/* Kullanicidan alinan sayi degeri ile 0 arasindaki degerleri toplayan ve sayilari
ekrana yazdiran programi recursive olarak kodlayiniz.
*/
#include <iostream>;
using namespace std;

int Topla(int sayi){			// int Topla(int,int,..)
	if(sayi<=0){
		return sayi;
	} else {
		return sayi + Topla(sayi-1);
	}
}
void SayiGoster(int sayi){
	int i=0;
	if(sayi < 0){
		cout << sayi;
	} else {
			while(i<=sayi){
			cout << i << " ";
			i++;
		}
    }
}
int main(){
	int sayi;
	cout << "Kacinci sayiya kadar toplama islemi yapilsin: ";
	cin >> sayi;
	cout << Topla(sayi)<<endl;
	cout << "Toplanan sayilar: ";
	SayiGoster(sayi);
	
	return 0;
}
