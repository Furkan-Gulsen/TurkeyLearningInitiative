// Bubble Sort (Kabarcik Siralama)
#include <iostream>
using namespace std;

void BubbleSort(int arr[],int arrLength) {
	for(int i=0;i<arrLength;i++) {
		for(int j=1;j<arrLength;j++){
			if(arr[j-1]>arr[j]) {
				int temp = arr[j-1];
				arr[j-1] = arr[j];
				arr[j] = temp;
			}
		}
	}
}

void Display(int arr[],int arrLength) {
	for(int i=0;i<arrLength;i++) {
		cout << arr[i] << " ";
	}
	cout << endl;
}

int main() {
	int dizi[10] = {10,2,0,14,43,25,18,-1,5,-45};
	int uzunluk = sizeof(dizi)/sizeof(dizi[0]);
	cout << "Siralanmamis dizi: "; Display(dizi,uzunluk);
	cout << "Bubble Sort ile siralanmis dizi: "; BubbleSort(dizi,uzunluk); Display(dizi,uzunluk);
	return 0;
}
