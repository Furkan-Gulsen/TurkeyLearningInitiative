#include <iostream>
using namespace std;
 // Linear Queue (Do�rusal Kuyruk)

const int KUYRUK_MAX = 5;

class DogrusalKuyruk{
	public:
		DogrusalKuyruk();    // Kuyrugu baslangic durumuna getirir. Kuyruk sonu ve Kuyruk basi degerlerine -1 atar.
		bool Ekle(int item); // Kuyrugun sonuna eleman ekler.
		int Cikar();		 // Kuyrugun basindaki elemani cikarir.
		bool BosMu();		 // Kuyruk bos mu kontrol eder.
		void Yazdir();		 // Kuyrugun basindan sonuna kadar tum elemanlari ekrana yazar.	
	private:	
		int D[KUYRUK_MAX];    // Kuyrugun elemanlarinin tutuldugu yer. (Kuyruk dizisi)
		int KS,KB;			  // KB: Kuyrugun ilk elemaninin indisini tutar.   KS: Kuyrugun son elemaninin indisini tutar.	
};

DogrusalKuyruk::DogrusalKuyruk() {
	KS = -1;
	KB = -1;	
}

bool DogrusalKuyruk::BosMu() {
	if(KS == -1 && KB == -1) {
		return true;
	}
	// else
	return false;
}

bool DogrusalKuyruk::Ekle(int item) {
	if(KS >= KUYRUK_MAX-1) {
		return false;
	}
	if(BosMu()) { 	// Eger kuyruk bos ise kuyruk basini 1 arttir.
		KB++;
	}
	KS++;	
	D[KS] = item;
	return true;
}

int DogrusalKuyruk::Cikar() {
	if(BosMu())			// Kuyruk bos oldugunda cikarilacak eleman olmadigi icin -1 dondurur.
		return -1;
	int i;
	int item = D[KB];
	KS--;
	for(i=0; i<=KS; i++) {
		D[i] = D[i+1];
	}	
	return item;
}

void DogrusalKuyruk::Yazdir() {
	for(int i=0; i<=KS; i++) {
		cout << D[i] << " ";
	}
}

int main() {
	DogrusalKuyruk object;
	object.Ekle(3);
	object.Ekle(6);
	object.Ekle(9);
	object.Ekle(12);
	object.Cikar();
	object.Yazdir();

	return 0;
}

