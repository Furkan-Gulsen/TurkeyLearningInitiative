#include <iostream>
using namespace std;
int A[] = { 23,78,45,8,32,56 };
void Merge(int alt, int orta, int ust){
	int i,j,k;
	i=alt;
	j=orta+1;
	while(i <= orta && j<= ust) {
		if(A[i] <= A[j]) {
			i++;
		} else {
			k = A[j];
			for(int x = j-1; x >= i; x--) {
				A[x+1] = A[x];
			}
			A[i] = k;
			i++; orta++; j++;
		}
	}
}

void MergeSort(int alt, int ust) {
	if(alt < ust) {
		int orta = (alt + ust) / 2;
		MergeSort(alt,orta);
		MergeSort(orta+1,ust);
		Merge(alt,orta,ust);
	}
}


int main() {
	MergeSort(0,5);
	for(int i=0;i<6; i++) {
		cout << A[i] << " ";
	}
	return 0;
}

