#include <iostream>
using namespace std;

class NewClass {
	private:
		int veri;
	public:
		void DegerAta(int deger) {
			cout << "Bir deger giriniz: ";
			cin >> deger;
			veri = deger;
		}
		void DegerYaz() {
			cout << "Girdiginiz veri: " << veri << endl;	
		}	
};

int main() {
	int deger;	
	NewClass reference1,reference2;
	
	reference1.DegerAta(deger);
	reference1.DegerYaz();
	
	reference2.DegerAta(deger);
	reference2.DegerYaz();
	
	cout << deger;	// output: 0
	
	return 0;
}

