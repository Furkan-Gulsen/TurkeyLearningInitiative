#include <iostream>
using namespace std;

#define BOYUT 5

int kuyruk[10],bas = -1, arka = -1;
 
void enQueue(int veri) { // Kuyruga eleman ekle
	if(arka == BOYUT)
		cout << "Kuyruk dolu";
	else {	// Kuyruga eleman eklenen kisim
		if(bas == -1)
			bas = 0;   	// Kuyruk bossa
		
		arka = arka + 1;
		kuyruk[arka] = veri;
	
	}	
}

void deQueue(){  // Kuyruktan eleman silme
	if(bas > arka) {	// Kuyrukta eleman kalmamissa
		cout << "Kuyruk bos" << endl;
		bas = -1;
		arka = -1;
	} else {
		kuyruk[bas] = 0;
		bas = bas + 1; 
	}
}

void Goster() {
	int i;
	for(i=bas; i<= arka; i++) {
		cout << kuyruk[i] << " ";
	}
	cout << endl;
}


int main() {
	enQueue(10);
	enQueue(5);
	enQueue(2);
	Goster();
	return 0;
}

